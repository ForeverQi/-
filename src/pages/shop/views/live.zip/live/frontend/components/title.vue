<template>
   <div class="container">
     <div class="left"></div>
     <div class="center"></div>
     <div class="right"></div>
   </div>
</template>

<script>
export default {
   name: '',
   data() {
       return {}
   },
  components: {}
}
</script>

<style scoped lang="scss">
.containner {
  height: .77rem;
  background: #fff;
}
</style>
