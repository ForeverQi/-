<template>
  <div>
     <router-view></router-view>
   </div>
</template>

<script>
export default {
  name: "",
  data() {
    return {};
  },
  components: {}
};
</script>

<style scoped></style>
