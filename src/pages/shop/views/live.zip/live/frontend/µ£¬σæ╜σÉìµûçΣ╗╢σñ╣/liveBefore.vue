<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: 'liveBefore',
        data(){
            return {

            }
        },
        methods:{
        }
    }
</script>

<style lang="scss">
</style>
