<template>
    <section class="orderList-box">
        <van-loading v-if="showLoading" size="50px" color="#1989fa" />
        <van-overlay :show="showLoading" />
        <div class="orderList" v-if="orderListInfo != ''">
            <div class="wrapper" >
            <!-- <div class="shoppingCat_title" :style="height: {{status + navHeight}}px; background:{{headcolor === 0 ? '' : headcolor}}" v-if=" isWho != 'ali'">
                <div class='status' :style="height: {{isWho == 'ali' ? '20' : status}}px;"></div>
                <div class='navbar' :style="height:{{isWho == 'ali' ? '44' : navHeight}}px;"> 
                    <span class="{{ headcolor === 0 ? 'shoppingCat_back shoppingCat_back2' : 'shoppingCat_back' }}" @click="goLink" v-if=" isWho != 'ali' " :style="padding-top:{{ isiOS ? '' : '40rpx' }}"></span>
                    <span class="shoppingCat_text" :style="color:{{headcolor === 0 ? '#222' : ''}}">{{wodedingdan}}</span>
                </div>
            </div> -->
                <div class="wrapper_c">
                <div class="wrapper_bg">
                    <div class="wrapper_bg_c"></div>
                </div>
                <div class="Max_Center">
                    <!-- 头部开始 -->
                    <div class="tab_head" v-if="head_info.length">
                    <div v-for="(item,index) in  head_info" :key="index" >
                        <div class="tab_head_li" v-if="index==0">
                        <div :style="{borderColor:cssColor}" @click="changeTitle(index)">{{item}}<span :style="{background:cssColor}" v-if="type==0" class="bottomXian"></span></div>
                        </div>
                        <div class="tab_head_li " v-if="index==1">
                        <div :style="{borderColor:cssColor}" @click="changeTitle(index)">{{item}}<span :style="{background:cssColor}" v-if="type==1" class="bottomXian"></span></div>
                        </div>
                        <div class="tab_head_li" v-if="index==2">
                        <div :style="{borderColor:cssColor}" @click="changeTitle(index)">{{item}}<span :style="{background:cssColor}" v-if="type==2" class="bottomXian"></span></div>
                        </div>
                        <div class="tab_head_li" v-if="index==3">
                        <div :style="{borderColor:cssColor}" @click="changeTitle(index)">{{item}}<span :style="{background:cssColor}" v-if="type==3" class="bottomXian"></span></div>
                        </div>
                        <div class="tab_head_li" v-if="index==4">
                        <div :style="{borderColor:cssColor}" @click="changeTitle(index)">{{item}}<span :style="{background:cssColor}" v-if="type==4" class="bottomXian"></span></div>
                        </div>
                    </div>
                    </div>
                    <!--订单列表 -->
                    <div class="order_list" v-if=" orderList.length > 0">
                    <div>
                            <div class="order_li" v-for="(item,index) in orderList" :key="index">
                            <div v-if="item.pro_info.pro_list.length > 0">
                                <div class="order_top">
                                <div class="state3" :style="{color:item.state_info.color_type == 2 ? '#999999' : item.state_info.color_type == 3 ? '#333333':''}">{{item.state_info.order_state}}</div>
                                <div class="shop_name">
                                    <div class="home_img" @click="shopMallFun(item.no_jump,item.shops_user_id)"><img src="https://aimg8.dlssyht.cn/xcx_pack/vip_shopmall/newOrder_home.png"/></div>
                                    <div class="home_txt" @click="shopMallFun(item.no_jump,item.shops_user_id)">{{item.shops_name}}</div>
                                    <div class="arrow1" v-if="item.shops_user_id > 0 && item.no_jump != 1"><img src="https://aimg8.dlssyht.cn/xcx_pack/vip_shopmall/newOrder_arrow1.png"/></div>
                                </div>
                                </div>
                                <div class="order_center" @click="goOrderdetail(item.order_type,item.id)">

                                <div class="order_name" :style="{paddingTop:item.order_type == 4 ? '0.2rem' : '0.05rem'}" v-if="item.pro_info.pro_list.length == 1">
                                    <div class="shop_img" v-if="item.order_type != 4"><img mode="aspectFill" :src="item.pro_info.pro_list[0].pic"/></div>
                                    <div class="shop_link">
                                    <div class="shop_link_tit">{{item.pro_info.pro_list[0].name}}</div>
                                    <div class="shop_link_txt">{{item.pro_info.pro_list[0].param_info}}</div>
                                    </div>
                                </div>
                                <div class="order_name" v-else>
                                    <div class="shop_img1" v-for="(proItem,proIndex) in item.pro_info.pro_list" :item="proItem" :index="proIndex" :key="proIndex"><img v-if="proIndex < 3" :src="proItem.pic"/></div>
                                </div>
                                <div class="order_money">
                                    <div class="money"><span :style="{marginRight:'0.03rem'}">{{CurrencySymbol}}</span>{{item.shiji_money_left}}<span>.{{item.shiji_money_right}}</span></div>
                                    <div class="Number" v-if="item.order_type != 4">{{item.pro_info.pro_number}}</div>
                                </div>
                                </div>
                                <div class=" order_foot " v-if="item.button_info.length" >
                                <div v-for="(btnItem,btnIndex) in item.button_info" :item="btnItem" :index="btnIndex" :key="btnIndex" >
                                <!-- 去支付 -->
                                <div v-if="btnItem.type == 'pay'" :style="{background:cssColor}" @click="navagatePage(0,'orderid='+item.id,'price='+item.total_amount)" class="navigator2">{{btnItem.name}}</div>
                                <!-- 取消订单 -->
                                <div v-if="btnItem.type == 'del'" class="navigator1" @click="changeYL(item.id)" >{{btnItem.name}}</div>
                                <!-- 申请退款 -->
                                <div v-if="btnItem.type == 'refund'" class="navigator1" @click="navagatePage(2,'orderid='+item.id)">{{btnItem.name}}</div>
                                <!-- 申请售后-- -->
                                <div v-if="btnItem.type == 'application'" @click="navagatePage(3,'orderid='+item.id,'proid='+item.pro_info.pro_list.length == 1 ? item.pro_info.pro_list[0].pro_id : 0,'detailid='+item.pro_info.pro_list.length == 1 ? item.pro_info.pro_list[0].id : 0,'buyindex='+index,'partygoods='+item.there_are_third_party_goods)" class="navigator1">{{btnItem.name}}</div>
                                <!-- 评价晒单 -->
                                <div @click="navagatePage(4,'orderid='+item.id,'detailid='+item.pro_info.pro_list.length == 1 ? item.pro_info.pro_list[0].id : 0)" v-if="btnItem.type == 'evaluate'" class="navigator1">{{btnItem.name}}</div>
                                <!--  再次购买-->
                                <div v-if="btnItem.type == 'buy'" class="navigator1" @click="navagatePage(5,'buyindex='+index)">{{btnItem.name}}</div>
                                <!-- 查看物流 -->
                                <div v-if="btnItem.type == 'logistics'" :style="{borderColor:cssColor,color:cssColor}" @click="navagatePage(6,'orderid='+item.id)" class="navigator3">{{btnItem.name}}</div>
                                <!-- 确认收货 -->
                                <div v-if="btnItem.type == 'receipt'" @click="okShouhuo(item.id)" class="navigator1">{{btnItem.name}}</div>
                                <!-- 订单二维码 -->
                                <div v-if="btnItem.type == 'qrcode'" :style="{width: btnItem.type == 'qrcode' ? '1.65rem' : ''}" class="navigator1" @click="navagatePage(7,'buyindex='+index,'img='+btnItem.img)">{{btnItem.name}}</div>
                                </div>
                                </div>
                                <!-- 已完成 -->
                                <div class="watermark" v-if="item.state_info.state_type == 3"><img src="https://aimg8.dlssyht.cn/xcx_pack/vip_shopmall/newOrder_complete.png"/></div>
                                <!-- 已失效 -->
                                <div class="watermark" v-if="item.state_info.state_type == 4"><img src="https://aimg8.dlssyht.cn/xcx_pack/vip_shopmall/newOrder_shixiao.png"/></div>
                            </div>
                        </div>
                    </div>

                        <!-- 到底了 -->
                    <div class="footerBox" v-if="page > pageCnt || pageCnt == 1">
                        <span>我也是有底线的~</span>
                    </div>
                    </div>

                    <div class="no_data" v-else>
                    <div class="no_data_img"><img src="https://aimg8.dlssyht.cn/xcx_pack/vip_shopmall/newOrder_no_data.png"/></div>
                    <div class="no_data_txt">{{orderListInfo.tips.meiyouxiangguandingdan}}</div>
                    </div>
                </div>
                <!-- 弹窗开始 -->
                <div class="alert_bg" catchtouchmove="noMove" v-if=" showModal" @click="shadowClose"></div>
                <div class="alert_c" v-if="refundConfim == 1">
                    <div class="alert_tit" catchtouchmove="noMove">
                    <div class="alert_tit_txt" v-if="cancelModel">{{orderListInfo.tips.quxiaodingdan}}</div>
                    <div class="alert_tit_txt" v-else>{{orderListInfo.tips.shenqingtuikuan}}</div>
                    <div class="Close" @click='no_show'><img src="https://aimg8.dlssyht.cn/xcx_pack/vip_shopmall/newOrder_Close.png"/></div>
                    </div>
                    <!-- 申请退款 -->
                    <div class="Reason1" v-if="!cancelModel" catchtouchmove="noMove">
                    <div class="Reason1_left">{{orderListInfo.tips.dingdanjinetuihuizhi}}</div>
                    <div class="Reason1_right">{{orderListInfo.tips.yuanlufanhui}}</div>
                    </div>
                    <div class="Reason2"  v-if="!cancelModel">
                    <div class="Reason1_left" catchtouchmove="noMove">{{orderListInfo.tips.quxiaodingdanyuanyin}}</div>

                    <div class="Reason1_right" @click='click'>{{cancel_reason[numReson]}}<div :class=" hiddenName == true ? 'arrow3':'arrow4 arrow3'"><img src="https://aimg8.dlssyht.cn/xcx_pack/vip_shopmall/newOrder_arrow3.png"/></div></div>
                    <div class="Reason_ul"  v-show="hiddenName">
                        <div class="Reason_li" v-for="(item,index) in cancel_reason" :key="index" @click="switchTab(index)">
                        <div :style="{borderColor:numReson == index ?cssColor:'',background:numReson == index ? cssColor : ''}" class="Reason_or">
                        <span :style="{color:'#fff'}" class="iconImage iconfont icon-duihao"></span>
                        </div>
                        <div class="Reason_or_txt">{{item}}</div>
                        </div>
                    </div>
                    </div>
                    <div class="Reason3" v-if="!cancelModel" catchtouchmove="noMove">
                    <spanarea v-show="!textareState" :placeholder="orderListInfo.tips.miaoshuneirong" :value="describe" @input="describeInput" @blur="textareaBlur" @focus="textareaFocus"></spanarea>
                    <div class="textareStateClass" v-show="textareState" @click="changeTextarea"> <span>{{describe ? describe : orderListInfo.tips.miaoshuneirong}}</span></div>
                    </div>
                    <!-- 取消订单文案 -->
                    <div class="cancelModel" catchtouchmove="noMove" v-if="cancelModel">{{orderListInfo.tips.shifouquxiaogaidingdan}}</div>
                    <div class="button_a" catchtouchmove="noMove" @click="cancelOrderBtn(cancelModel ? 'del' : 'refund')" :style="{background:cssColor}">{{orderListInfo.tips.queren}}</div>
                </div>
                <!-- 弹窗结束 -->

                <!-- 供应链申请退款弹窗 -->
                <div class="alert_bg" catchtouchmove="noMove" v-if="refundConfim == 2" @click="shadowClose"></div>
                <div class="alert_c" v-if="refundConfim == 2">
                    <div class="alert_tit" catchtouchmove="noMove">
                    <div class="alert_tit_txt" v-if="cancelModel">{{orderListInfo.tips.quxiaodingdan}}</div>
                    <div class="alert_tit_txt" v-else>{{orderListInfo.tips.shenqingtuikuan}}</div>
                    <div class="Close" @click='no_show'><img src="https://aimg8.oss-cn-shanghai.aliyuncs.com/xcx_pack/vip_shopmall/newOrder_Close.png"/></div>
                    </div>
                    <!-- 申请退款 -->
                    <div class="Reason2">
                    <div class="Reason1_left" catchtouchmove="noMove" :style="{flex:none,marginRight:'0.65rem',fontSize:'0.28rem',width:'2rem'}">订单金额退回至</div>
                    <input class="Reason1_right placeholderClass" :style="{flex:auto,fontSize:'0.28rem'}" @click="click" :value="cancel_reason[numReson]" placeholder="请选择退款原因" :disabled="true"/>
                    <div :class="hiddenName == true ? 'arrow3':'arrow4 arrow3'"><img src="https://aimg8.oss-cn-shanghai.aliyuncs.com/xcx_pack/vip_shopmall/newOrder_arrow3.png"/></div>
                    <div class="Reason_ul"  v-show="hiddenName">
                        <div class="Reason_li" v-for="(item,index) in cancel_reason" :key="index" @click="switchTab(index)">
                        <div :style="{borderColor:numReson == index ?cssColor:'',background:numReson == index ? cssColor : ''}" class="Reason_or">
                        <span :style="{color:'#fff'}" class="iconImage iconfont icon-duihao"></span>
                        </div>
                        <div class="Reason_or_txt">{{item}}</div>
                        </div>
                    </div>
                    </div>
                    <div class="Reason2">
                    <div class="Reason1_left" catchtouchmove="noMove" :style="{flex:none,marginRight:'0.65rem',fontSize:'0.28rem',width:'2rem'}">联系人</div>
                    <input class="Reason1_right placeholderClass" :style="{flex:auto,fontSize:'0.28rem'}" value="" placeholder="请输入联系人"/>
                    </div>
                    <div class="Reason2" :style="{marginBottom:'0.35rem'}">
                    <div class="Reason1_left" catchtouchmove="noMove" :style="{flex:none,marginRight:'0.65rem',fontSize:'0.28rem',width:'2rem'}">联系方式</div>
                    <input class="Reason1_right placeholderClass" :style="{flex:auto,fontSize:'0.28rem'}" value="" placeholder="请输入联系方式"/>
                    </div>
                    <div class="warnInfo"><img src="https://aimg8.oss-cn-shanghai.aliyuncs.com/xcx_pack/vip_shopmall/warn.png"/> 取消订单时仅返还商品金额，运费不退</div>
                    <div class="button_a" catchtouchmove="noMove" @click="cancelOrderBtn(cancelModel ? 'del' : 'refund')" :style="{background:cssColor}">{{orderListInfo.tips.shenqingtuikuan}}</div>
                </div>
                </div>

                <!-- 透明层，防止连点 -->
                <div class="opacityView" v-if="payStatus"></div>
                <!-- 二维码弹窗 -->
                <div class="erweima_box" v-if=" imgSrc != ''">
                <div class="erweima">
                    <div class="erweima_top">
                    <img :src="imgSrc"/>
                    <span v-if="userName == 'lxkj_zsc'">商家微信扫码</span>
                    <span v-else-if="userName == 'ywgshop'">通过商家APP扫码确认</span>
                    <span v-else>使用商家助手-APP扫描确认订单</span>
                    </div>
                    <div class="erweima_bottom" catchtap="claoseMa">
                        关闭
                    </div>
                </div>
                </div>
            </div>

        </div>
    </section>
</template>

<script>
    // vant组件
    import Hint from "@/plugins/hint";
    // 订单列表，购物车列表,确认收货，取消订单
    import { getOrderList,cartList,orderShouhuo,orderHandle } from "@/api/order/orderList.js";
    export default {
        data(){
            return {
                head_info:[],
                // 蒙版显示判断
                showModal: false,
                hiddenName: true,
                objarray: [{
                    img: "https://aimg8.oss-cn-shanghai.aliyuncs.com/xcx_pack/vip_shopmall/newOrder_or.jpg",
                    text: "不想买了",
                }, {
                    img: "https://aimg8.oss-cn-shanghai.aliyuncs.com/xcx_pack/vip_shopmall/newOrder_or.jpg",
                    text: "缺少件",
                }, {
                    img: "https://aimg8.oss-cn-shanghai.aliyuncs.com/xcx_pack/vip_shopmall/newOrder_or.jpg",
                    text: "质量问题",
                }],
                num: 0,
                page: 1,
                pageCnt: 0,
                type: 0,
                orderList: [],
                numReson: 0,
                describe: '',
                state: 0,
                fasterNum: 0,
                textareState: false,
                imgSrc: '',
                orderListInfo:'',
                showLoading: true, //加载动画
                CurrencySymbol:"￥",
                refundConfim:0,
                cancelModel:false,
                payStatus:false
            }
        },
        mounted() {
            let state = 0,
                that = this;

                that.state= state;
                that.type= state;
                that.cssColor= "#8D524A";
            // 色系值
            // util.getNavSet(function (res) {
            //     that.setData({
            //         cssColor: res.xcolor
            //     });
            //     if (res.title_color && res.title_color.length > 0 && res.title_color != '#ffffff') {
            //         that.setData({
            //             headcolor: res.title_color
            //         });
            //     } else {
            //         that.setData({
            //             headcolor: 0
            //         });
            //     }
            //     util.setNavSize();
            //     that.orderList(state);
            // });
            that.orderListFun(0);
            that.headcolor = 0;
            //获取货币符号
            // util.symbol();
        },
        methods: {
            // 列表接口
            orderListFun(state) {
                let that = this;
                that.showLoading = true;
                let paramJson={
                    state: state,
                    page: that.page,
                    username:'jzabcdemo',
                    zz_userid:24423062
                }
                getOrderList(paramJson).then(res=>{
                        that.showLoading = false;
                        // 修改标题
                        // util.SetNavigationBarTitle({
                        //     title: res.tips.wodedingdan
                        // });
                        let orderList = that.orderList.concat(res.order_list);
                        for (let i in orderList) {
                            let val;
                            if (typeof (orderList[i].total_amount) == String) {
                                val = orderList[i].total_amount;
                            } else {
                                val = String(orderList[i].total_amount);
                            }
                            let val_left = val.substring(0, val.indexOf("."));
                            let val_right = val.replace(/\d+\.(\d*)/, '$1');
                            orderList[i].shiji_money_left = val_left;
                            orderList[i].shiji_money_right = val_right;
                        }
                        that.orderListInfo= res,
                        that.orderList= orderList,
                        that.pageCnt= res.page_cnt,
                        that.head_info= res.head_info,
                        that.cancel_reason= res.cancel_reason,
                        that.wodedingdan= res.tips.wodedingdan
                }).catch(err=>{
                     Hint.Alert({
                           message: err.msg,
                    }).then(() => {
                        // on close
                        if (document.referrer.length > 0) {
                                window.history.back();
                        }else{
                            // location.href = this.videoData[0].index_url
                        }
                    });
                });
            },
            // 选择title
            changeTitle(type) {
                this.page= 1;
                this.type= type;
                this.orderList= [];
                this.state= type;
                this.orderListFun(type);
            },

            // 购物车接口封装
            joinShoppCat(index) {
                let that = this,
                    proList = that.orderList[index].pro_info.pro_list;
                that.showLoading = true;

                let paramValue, add_pro_info_json = {},
                    add_pro_info_num = {
                        num: 1
                    },
                    add_pro_info_id, add_pro_info_id2 = '';
                for (let i in proList) {
                    add_pro_info_id = proList[i].pro_id + '_' + proList[i].param_id;
                    add_pro_info_id2 = add_pro_info_id2 + proList[i].pro_id + '_' + proList[i].param_id + ',';
                    add_pro_info_json[add_pro_info_id] = add_pro_info_num;
                }
                add_pro_info_id2 = add_pro_info_id2.substring(0, add_pro_info_id2.length - 1);
                var zz_userid = that.$cookies.get("zz_userid");
                // 购物车列表
                paramValue = {
                    type: 1,
                    ids: add_pro_info_id2,
                    check: 1,
                    add_pro_info: JSON.stringify(add_pro_info_json),
                    xcx_req: 1,
                    user_user_id: zz_userid,
                    is_addtocar: 1
                };
                // 请求购物车列表接口
                cartList(paramValue).then(res =>{
                    that.showLoading = false;
                }).catch(err=>{
                    Hint.Msg({
                        message:res.msg
                    })
                })
            },

            /**
             * 页面上拉触底事件的处理函数
             */
            onReachBottom: function () {
                let that=this, page = that.page;
                // if (page <= this.pageCnt && this.pageCnt > 1) {
                //     page++;
                //     this.setData({
                //         page: page
                //     });
                //     this.orderList(this.state);
                // } else {
                //     this.setData({
                //         noData: true
                //     });
                // }
                $(".orderList"+that.current).scroll(function() {
                    var nScrollHight = 0; //滚动距离总长(注意不是滚动条的长度)
                    var nScrollTop = 0; //滚动到的当前位置
                    var nDivHight = $(".orderList"+that.current).height();
                    nScrollHight = $(that)[0].scrollHeight;
                    nScrollTop = $(that)[0].scrollTop;

                    if (nScrollTop + nDivHight >= nScrollHight) {
                        that.page = page++
                        that.orderListFun(this.state);
                    }
            });
            },
            /**
             * 取消订单弹窗
             */
            changeYL(id) {
                this.showModal= true;
                this.refundConfim= 1;
                this.cancelModel= true;
                this.buyCancelId= id
            },
            shadowClose() {
                this.showModal= false;
                this.refundConfim= 0;
                this.cancelModel= true;
            },
            // 取消订单接口,退款
            cancelOrderBtn(type) {

                let that = this,
                    jsonValue = {
                        order_id: that.buyCancelId
                    };
                if (type == 'del') { //取消订单
                    jsonValue.operation = 'del';
                } else if (type == 'refund') { //退款
                    jsonValue.operation = 'refund';
                    let req = {};
                    req.return_accounts = 1;
                    req.other_description = Number(this.numReson) + 1;
                    req.description = this.describe;
                    jsonValue.req = JSON.stringify(req);
                }
                orderHandle(jsonValue).then(res => {
                    Hint.Msg({
                        message: res.msg,
                    })
                    that.showModal= false;
                    that.refundConfim= 0;
                    that.orderList= [];
                    that.page= 1;
                    setTimeout(function () {
                        that.orderListFun(that.state);
                    }, 200);
                }).catch(err => {
                    //弹出警示信息
                    Hint.Alert({
                        message: res.msg,
                    }).then(()=>{
                        that.showModal= false;
                        that.refundConfim= 0;
                        that.orderList= [];
                        that.page= 1;
                        setTimeout(function () {
                            that.orderListFun(that.state);
                        }, 200);
                    })
                })
            },

            hideModal () {
                this.showModal= false;
                this.refundConfim= 0
            },

            changeTextarea() {
                this.textareState= !this.textareState;
            },
            textareaFocus() {
                this.textareState= true;
                this.textareState2= true;
            },
            textareaBlur() {
                this.textareState= !this.textareState;
                this.textareState2= false;
            },
            /**
             * 关闭订单弹窗
             */
            no_show () {
                this.showModal= false;
                this.refundConfim= 0;
            },
            /**
             * 取消订单原因
             */
            click() {
                this.hiddenName= !this.hiddenName;
                this.textareState= false;
            },

            // 页面跳转
            navagatePage(type,val,val2,val3,val4,val5) {
                let req = {
                        type: 1
                    };
                    if(val && that.getArrSecond(val)[0] == "orderid"){
                        var orderId = that.getArrSecond(val)[0];
                    }
                    if(val && that.getArrSecond(val)[0] == "buyindex"){
                        var buyIndex = that.getArrSecond(val)[0];
                    }
                    if(val2 && that.getArrSecond(val2)[0] == "price"){
                        var price = that.getArrSecond(val)[0];
                    }
                    if(val2 && that.getArrSecond(val2)[0] == "proid"){
                        var proid = that.getArrSecond(val)[0];
                    }
                    if(val2 && that.getArrSecond(val2)[0] == "buyindex"){
                        var buyIndex = that.getArrSecond(val)[0];
                    }
                    if(val2 && that.getArrSecond(val2)[0] == "img"){
                        var img = that.getArrSecond(val)[0];
                    }
                    if(val3 && that.getArrSecond(val3)[0] == "detailid"){
                        var detailid = that.getArrSecond(val)[0];
                    }
                    if(val4 && that.getArrSecond(val4)[0] == "buyindex"){
                        var buyindex = that.getArrSecond(val)[0];
                    }
                    if(val5 && that.getArrSecond(val5)[0] == "partygoods"){
                        var partygoods = that.getArrSecond(val)[0];
                    }
                switch (Number(type)) {
                    case 0: // 去支付
                        this.payStatus= true;
                        let success_url = '/extvideo/pages/order/orderDetail?orderId=' + orderId;
                        let fail_url = '/extvideo/pages/order/orderDetail?orderId=' + orderId;
                        fail_url = fail_url + '&is_pay=1';
                        this.payMoney(orderId, price, success_url, fail_url);
                        break;
                    case 2: // 申请退款
                        this.showModal= true,
                        // 1是普通订单 2是供应链订单
                        this.refundConfim= true ? 1 : 2;
                        this.cancelModel= false;
                        this.buyCancelId= orderId;
                        break;
                    case 3: // 商品申请售后
                        if (this.orderList[buyIndex].pro_info.pro_list.length == 1) {
                            // 供应链
                            if (partygoods == 1) {
                                wx.navigateTo({ //单个商品
                                    url: `/extvideo/pages/order/jdAfterType?jdStatus=1&detailId=${detailId}&orderId=${orderId}&proid=${proid}`,
                                });
                            } else { //非供应链
                                wx.navigateTo({ //单个商品
                                    url: `/extvideo/pages/order/returnGoods?orderId=${orderId}&detailId=${detailId}&redirect=orderList`,
                                });
                            }
                        } else {
                            wx.navigateTo({ //多个商品
                                url: `/extvideo/pages/order/afterSales?orderId=${orderId}&detailId=${detailId}`,
                            });
                        }
                        break;
                    case 4:
                        //晒单评价
                        if (that.$util.functions.ifHaveFun(detailId)) {
                            wx.navigateTo({
                                url: `/extvideo/pages/order/evaluation?orderId=${orderId}&detailId=${detailId}&req=${JSON.stringify(req)}&is_add=0&orderValue=1&state=${this.state}`,
                            });
                        } else {
                            wx.navigateTo({
                                url: `/extvideo/pages/order/evaluationList?orderId=${orderId}&req=${JSON.stringify(req)}`,
                            });
                        }
                        break;
                    case 5:
                        //加入购物车||商品详细||点餐
                        let typeValue = this.orderList[buyIndex].pro_info.repurchase_info.type;
                        if (typeValue == 1) {
                            this.joinShoppCat(buyIndex);
                        } else if (typeValue == 2) {
                            wx.navigateTo({
                                url: '/pages/product/details?proid=' + this.orderList[buyIndex].pro_info.repurchase_info.pro_id,
                            });
                        }
                        break;
                    case 6:
                        //查看物流
                        wx.navigateTo({
                            url: '/extvideo/pages/order/orderRecord?id=' + orderId,
                        });
                        break;
                    case 7:
                        //订单二维码
                        let url = 'https://' + app.globalData.host + img;
                        this.imgSrc= url;
                        this.userName= app.globalData.userName;
                        break;
                }
            },
            claoseMa() {
                this.imgSrc= '';
            },
            // 跳转商铺
            shopMallFun(nojump,id,name) {
                // 供应链的商铺 等于1不能跳转
                if (id > 0 && nojump != 1) {
                    wx.navigateTo({
                        url: '/extpack/pages/shops/shop_details?u_u_id=' + id
                    });
                }
            },

            // 跳转订单详情
            goOrderdetail(type,id) {
                if (type == 34) {
                    wx.navigateTo({
                        url: "/extpack/pages/hotel/order_detail?order_id=" + id,
                    });
                } else {
                    wx.navigateTo({
                        url: "/extvideo/pages/order/orderDetail?orderId=" + id,
                    });
                }
            },

            // 取消订单描述
            describeInput(e) {
                let detail = e.detail.value;
                this.setData({
                    describe: detail
                });
            },
            // 支付接口
            payMoney(id, price, success_url, fail_url) {

                let paydata = {
                    orderid: id,
                    ordertype: 'pro',
                    price: price
                };
                // util.payments({
                //     data: paydata,
                //     success: function () {
                //         wx.hideLoading();
                //         wx.redirectTo({
                //             url: success_url
                //         });
                //     },
                //     fail: function () {
                //         wx.hideLoading();
                //         wx.redirectTo({
                //             url: fail_url
                //         });
                //     },
                //     complete: function () {
                //         this.setData({
                //             payStatus: false
                //         });
                //     }
                // });
            },

            //确认收货
            okShouhuo (id) {
                var that = this,zz_userid = that.$cookies.get("zz_userid");

                return Hint.Confirm({
                    title: '确认收货？',
                    message: '您确定要确认收货吗？确认后将不能更改！'
                }).then(() => {
                    orderShouhuo({id:id}).then(res=>{
                        if (res.data == -1) {
                                Hint.Alert({
                                    title:'提示',
                                    message: "参数错误",
                                })
                            } else if (res.data == 0) {
                                Hint.Alert({
                                    title:'提示',
                                    message: "服务器繁忙！",
                                })
                            } else if (res.data == 1) {
                                Hint.Alert({
                                    title:'提示',
                                    message: "您的订单状态还未在配送中，不能确认收货！",
                                })
                            } else {
                                Hint.Alert({
                                    title:'提示',
                                    message: "确认收货成功",
                                }).then(()=>{
                                        that.showModal= false;
                                        that.orderList= [];
                                        that.page= 1;
                                        that.orderListFun(that.state);
                                })
                            }
                    })
                });
            },

            /**
             * 取消订单原因选择
             */
            switchTab(index) {
                this.numReson= parseInt(index);
            },
            noMove() {
                return false;
            },
            // 返回到订单列表
            goLink() {
                // wx.navigateTo({
                //     url: '/pages/personal/list',
                // });
            },
            // 将字符串根据=分开为数组
            getArrSecond(data){
                return data.split('=');
            },
        }
    };
</script>

<style lang="scss" scoped>
    @import "@/pages/order/assets/css/orderList.scss";
</style>
