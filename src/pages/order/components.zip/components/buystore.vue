<!--
 * @Author       : zhouqi
 * @description  : description
 * @Date         : 2020-11-19 17:28:41
 * @LastEditors  : zhouqi
 * @LastEditTime : 2020-11-20 16:04:03
 * @FilePath     : /vue-VFrontend/src/pages/order/components/buystore.vue
-->
<template>
    <div class="buystore-box">
        <div class="buystore">
            <!-- 购买门店 -->
            <CustomPopup ref="buyStoreRef" class="payWay" v-if="buyStoreStatus" @closeStoreFun="closeStoreFun(1)">
                <div slot="PoperContentHigh" class="changeCityClass">
                    <div class="changeCityBox" >
                        <div class="changeCityBox_top" style="border-bottom:0;">
                            <div class="changeCityBox_top_left changeCityBox_top_left_heng">
                                <span>请选择购买门店</span>
                            </div>
                            <div class="changeCityBox_top_right" @click="closeStoreFun(1)">
                                <div class="weixinAdress_closeIcon">
                                    <span class="weixinAdress_closeIcon_left"></span>
                                    <span class="weixinAdress_closeIcon_right"></span>
                                </div>
                            </div>
                        </div>
                        <div class="distribution_content">
                            <div v-if="storeParam.store.store_list.length">
                                <div class="distribution_ListValue" @click="sotesClick(index)" v-for="(item,index) in storeParam.store.store_list" :key="index">
                                    <div class="weixinAdress_closeIcon">
                                        <div class="distribution_ListTop_right">
                                            <div
                                                :class="
                                                    item.is_check == 1
                                                        ? 'shoppingContent_checkRadio shoppingContent_radio'
                                                        : 'shoppingContent_radio'
                                                "
                                                :style="{
                                                    background: item.is_check == 1 ? bgcColor1 : '',
                                                    borderColor: item.is_check == 1 ? bgcColor1 : '' + '!important'
                                                }"
                                            >
                                                <img
                                                    src="https://aimg8.dlssyht.cn/xcx_pack/vip_shopmall/check.png"
                                                    alt="check"
                                                    v-if="item.is_check == 1"
                                                />
                                            </div>
                                        </div>
                                        <div class="distribution_ListTop_left">
                                            <span>{{item.name}}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div v-else class="noPeiSong" style="margin-left:-0.26rem;">
                                <div class="changeCityBox_content_noValue payCard_noCard">
                                    <img
                                        src="https://aimg8.dlssyht.cn/xcx_pack/vip_shopmall/submit_envelopeOrder.png"
                                        alt="城市"
                                    />
                                    <span class="openPermissions">暂无可选购买门店</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="PoperContentBtn" @click="closeStoreFun(1)" :style="{ color: bgcColor1 }">{{storeParam.store.tips.queren}}</div>
                </div>
            </CustomPopup>
        </div>
    </div>
</template>

<script>
const { log } = console;
// vant组件
import Hint from "@/plugins/hint";
// 弹窗插槽组件
import CustomPopup from "@/components/CustomPopup/custompopup.vue";
export default {
    props: {
        storeParam:{
            type:Object,
            default:{}
        }
    },
    data() {
        return {
            bgcColor1: "#f00",
            buyStoreStatus: false
        };
    },
    components: {
        CustomPopup
    },
    methods: {
        // 展开购买门店
        buyShow() {
            let that = this;
            that.buyStoreStatus = true;
            log(that.storeParam);
            that.$forceUpdate();
            setTimeout(() => {
                that.$refs.buyStoreRef.showCustom();
            });
        },
        /**
         * @Date: 2020-11-19 19:25:05
         * @LastEditors: zhouqi
         * @description: 关闭弹窗
         * @param {type} 1:购买门店
         * @return {*}
         */
        closeStoreFun(type) {
            if (type == 1) {

                this.$refs.buyStoreRef.maskClickHidden();
            }
        },
        /**
         * @Date: 2020-11-19 19:57:30
         * @LastEditors: zhouqi
         * @description: 购买门店点击
         * @param {*} index:索引
         * @return {*}
         */        
        sotesClick(index){
            let that = this, data = that.changeFun(that.storeParam.store.store_list,1,index,'cancel'),dataJson={},num=0;
            for(let i in data.array){
                if(data.array[i].is_check == 1){
                    num++
                    dataJson.id=data.array[i].id;
                    dataJson.name=data.array[i].name;
                }
            }
            if(num ==0){
                dataJson.id=0;
                dataJson.id='';
            }
            that.$forceUpdate();
            that.$emit("storeFun",dataJson)
        },

        // 返回选中的Array
        changeFun(changeArray, id, index, type) {
            let changeJson = {};
            for (let i in changeArray) {
                if (i == index) {
                    if (type == "nocancel") {
                        //不可取消
                        changeArray[i].is_check = 1;
                    } else {
                        changeArray[i].is_check = changeArray[i].is_check == 1 ? 0 : 1;
                        id = changeArray[i].is_check == 1 ? changeArray[i].id : 0;
                    }
                    if (this.payWayVal == 1) {
                        //返回支付方式的pay_id
                        changeJson.zf_pay_id = changeArray[i].is_check == 1 ? changeArray[i].pay_id : 0;
                        if (id == 0 || id == 2) {
                            changeArray[i].is_check == 1 ? id : -1;
                        }
                    } else {
                        changeJson.zf_pay_id = 0;
                    }
                    if (changeArray[i].is_check == 0) {
                        if (this.payWayVal == 1) {
                            //返回支付方式的pay_id
                            changeJson.zf_pay_id = 0;
                            id = 0;
                        }
                        break;
                    }

                    if (id == 1) {
                        id = changeArray[i].is_check == 1 ? changeArray[i].id : 0;
                    } else if (id == 0) {
                        this.yearDate = changeArray[i].date;
                    }
                } else {
                    changeArray[i].is_check = 0;
                }
            }
            changeJson.array = changeArray;
            changeJson.id = id;
            return changeJson;
        },
    }
};
</script>

<style lang="scss">
@import "@/pages/order/assets/css/buystore.scss";
</style>
